<?php

namespace App\Controllers\Perusahaan;

use App\Controllers\BaseController;

class Dashboard extends BaseController
{
    public function index()
    {
        return view('perusahaan/nav/header') .view('perusahaan/dashboard') .view('perusahaan/nav/footer');
    }
}
