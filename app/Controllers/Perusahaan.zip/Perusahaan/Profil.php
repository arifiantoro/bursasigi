<?php

namespace App\Controllers\Perusahaan;

use App\Controllers\BaseController;

class Profil extends BaseController
{
    public function index()
    {
        return view('perusahaan/nav/header') . view('perusahaan/profil/view') . view('perusahaan/nav/footer');
    }

    public function edit()
    {
        return view('perusahaan/nav/header') . view('perusahaan/profil/atur-profile') . view('perusahaan/nav/footer');
    }
}
